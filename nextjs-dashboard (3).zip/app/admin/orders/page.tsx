import { Suspense } from "react"
import { AdminOrdersList } from "@/components/admin/orders/admin-orders-list"
import { DashboardSkeleton } from "@/components/skeletons"
import { ErrorBoundary } from "@/components/error-boundary"

export default function AdminOrdersPage() {
  return (
    <main className="flex-1">
      <ErrorBoundary fallback={<div className="p-4">Something went wrong loading orders</div>}>
        <Suspense fallback={<DashboardSkeleton />}>
          <AdminOrdersList />
        </Suspense>
      </ErrorBoundary>
    </main>
  )
}

