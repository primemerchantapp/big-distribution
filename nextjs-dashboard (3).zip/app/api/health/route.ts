import { NextResponse } from "next/server"
import { db } from "@/lib/firebase-admin"

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const service = searchParams.get("service")

  try {
    // Check database connection
    if (service === "database") {
      try {
        // Perform a simple query to check database connection
        await db.collection("system_health").doc("status").get()
        return NextResponse.json({ status: "online", message: "Database connection successful" })
      } catch (error) {
        console.error("Database health check failed:", error)
        return NextResponse.json({ status: "error", message: "Database connection failed" }, { status: 500 })
      }
    }

    // Check API service
    if (service === "api") {
      // This endpoint being reachable means the API is working
      return NextResponse.json({ status: "online", message: "API service is operational" })
    }

    // Check storage service
    if (service === "storage") {
      try {
        // Check storage bucket access
        const bucket = db.storage().bucket()
        await bucket.exists()
        return NextResponse.json({ status: "online", message: "Storage service is accessible" })
      } catch (error) {
        console.error("Storage health check failed:", error)
        return NextResponse.json({ status: "error", message: "Storage service check failed" }, { status: 500 })
      }
    }

    // General health check
    return NextResponse.json({ status: "online", message: "System is operational" })
  } catch (error) {
    console.error("Health check failed:", error)
    return NextResponse.json({ status: "error", message: "Health check failed" }, { status: 500 })
  }
}

