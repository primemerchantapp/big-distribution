import { Suspense } from "react"
import { CustomerDetails } from "@/components/customers/customer-details"
import { CustomerDetailsSkeleton } from "@/components/skeletons"
import { ErrorBoundary } from "@/components/error-boundary"

export default function CustomerDetailsPage({ params }: { params: { id: string } }) {
  return (
    <main className="flex-1 p-8 pt-6">
      <div className="flex items-center justify-between space-y-2">
        <h2 className="text-3xl font-bold tracking-tight">Customer Details</h2>
      </div>
      <div className="mt-4">
        <ErrorBoundary fallback={<div className="p-4">Something went wrong loading customer details</div>}>
          <Suspense fallback={<CustomerDetailsSkeleton />}>
            <CustomerDetails id={params.id} />
          </Suspense>
        </ErrorBoundary>
      </div>
    </main>
  )
}

