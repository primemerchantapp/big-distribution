import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { FileText, Download, ExternalLink } from "lucide-react"

export default function ResourcesPage() {
  return (
    <div className="flex-1 space-y-4 p-8 pt-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Resources</h2>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle>User Manual</CardTitle>
            <CardDescription>Complete guide for using the dashboard</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="mb-4 text-sm text-muted-foreground">
              Learn how to use all features of the dashboard with step-by-step instructions.
            </p>
            <Button className="w-full">
              <FileText className="mr-2 h-4 w-4" />
              View Manual
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Training Videos</CardTitle>
            <CardDescription>Video tutorials for common tasks</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="mb-4 text-sm text-muted-foreground">
              Watch video tutorials on how to manage customers, orders, and more.
            </p>
            <Button className="w-full" variant="outline">
              <ExternalLink className="mr-2 h-4 w-4" />
              Access Videos
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Report Templates</CardTitle>
            <CardDescription>Excel templates for custom reporting</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="mb-4 text-sm text-muted-foreground">
              Download Excel templates for creating custom reports with your data.
            </p>
            <Button className="w-full" variant="outline">
              <Download className="mr-2 h-4 w-4" />
              Download Templates
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>API Documentation</CardTitle>
            <CardDescription>Technical documentation for developers</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="mb-4 text-sm text-muted-foreground">
              Technical documentation for integrating with our API endpoints.
            </p>
            <Button className="w-full" variant="outline">
              <FileText className="mr-2 h-4 w-4" />
              View Documentation
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Support Center</CardTitle>
            <CardDescription>Get help with any issues</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="mb-4 text-sm text-muted-foreground">
              Contact our support team or browse through frequently asked questions.
            </p>
            <Button className="w-full">
              <ExternalLink className="mr-2 h-4 w-4" />
              Visit Support Center
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Release Notes</CardTitle>
            <CardDescription>Latest updates and changes</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="mb-4 text-sm text-muted-foreground">
              Stay updated with the latest features, improvements, and bug fixes.
            </p>
            <Button className="w-full" variant="outline">
              <FileText className="mr-2 h-4 w-4" />
              View Release Notes
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

