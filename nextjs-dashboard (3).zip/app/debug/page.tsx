import { TestLogin } from "@/components/auth/test-login"

export default function DebugPage() {
  return (
    <div className="flex min-h-screen items-center justify-center p-4">
      <TestLogin />
    </div>
  )
}

