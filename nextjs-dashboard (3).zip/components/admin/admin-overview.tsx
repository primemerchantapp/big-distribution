"use client"

import { useEffect, useState } from "react"
import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis, Tooltip } from "recharts"
import { collection, query, getDocs } from "firebase/firestore"
import { db } from "@/lib/firebase"

export function AdminOverview() {
  const [data, setData] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchSalesData = async () => {
      try {
        setLoading(true)

        const now = new Date()
        const currentYear = now.getFullYear()

        // Create an array of month names
        const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]

        // Initialize data with all months set to 0
        const initialData = monthNames.map((name, index) => ({
          name,
          total: 0,
          month: index,
        }))

        // Fetch orders for the current year
        const ordersQuery = query(collection(db, "orders"))

        const ordersSnapshot = await getDocs(ordersQuery)

        // Process orders and aggregate by month
        ordersSnapshot.forEach((doc) => {
          const orderData = doc.data()

          if (orderData.createdAt) {
            const orderDate = orderData.createdAt.toDate()
            const orderYear = orderDate.getFullYear()

            if (orderYear === currentYear) {
              const orderMonth = orderDate.getMonth()
              initialData[orderMonth].total += orderData.totalAmount || 0
            }
          }
        })

        setData(initialData)
      } catch (error) {
        console.error("Error fetching admin sales data:", error)
        setData([])
      } finally {
        setLoading(false)
      }
    }

    fetchSalesData()
  }, [])

  // If loading or no data, show placeholder
  if (loading) {
    return (
      <div className="h-[300px] flex items-center justify-center">
        <p className="text-muted-foreground">Loading sales data...</p>
      </div>
    )
  }

  if (data.length === 0) {
    return (
      <div className="h-[300px] flex items-center justify-center">
        <p className="text-muted-foreground">No sales data available</p>
      </div>
    )
  }

  return (
    <ResponsiveContainer width="100%" height={350}>
      <BarChart data={data}>
        <XAxis dataKey="name" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
        <YAxis
          stroke="#888888"
          fontSize={12}
          tickLine={false}
          axisLine={false}
          tickFormatter={(value) => `₱${value}`}
        />
        <Tooltip formatter={(value) => [`₱${value}`, "Total"]} labelFormatter={(label) => `Month: ${label}`} />
        <Bar dataKey="total" fill="currentColor" radius={[4, 4, 0, 0]} className="fill-primary" />
      </BarChart>
    </ResponsiveContainer>
  )
}

