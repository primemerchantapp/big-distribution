"use client"

import { useEffect, useState } from "react"
import { collection, query, orderBy, limit, getDocs } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { formatDistanceToNow } from "date-fns"

export function AdminRecentActivity() {
  const [activities, setActivities] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchRecentActivity = async () => {
      try {
        setLoading(true)

        // Fetch recent orders
        const ordersQuery = query(collection(db, "orders"), orderBy("createdAt", "desc"), limit(3))

        const ordersSnapshot = await getDocs(ordersQuery)
        const orderActivities = ordersSnapshot.docs.map((doc) => {
          const data = doc.data()
          return {
            id: doc.id,
            type: "order",
            description: `New order #${doc.id.substring(0, 6)} created`,
            timestamp: data.createdAt?.toDate() || new Date(),
            status: data.status || "pending",
          }
        })

        // Fetch recent customers
        const customersQuery = query(collection(db, "customers"), orderBy("createdAt", "desc"), limit(3))

        const customersSnapshot = await getDocs(customersQuery)
        const customerActivities = customersSnapshot.docs.map((doc) => {
          const data = doc.data()
          return {
            id: doc.id,
            type: "customer",
            description: `New customer ${data.name || "Unknown"} registered`,
            timestamp: data.createdAt?.toDate() || new Date(),
            status: "active",
          }
        })

        // Fetch recent agents
        const agentsQuery = query(collection(db, "agents"), orderBy("createdAt", "desc"), limit(3))

        const agentsSnapshot = await getDocs(agentsQuery)
        const agentActivities = agentsSnapshot.docs.map((doc) => {
          const data = doc.data()
          return {
            id: doc.id,
            type: "agent",
            description: `New agent ${data.name || "Unknown"} onboarded`,
            timestamp: data.createdAt?.toDate() || new Date(),
            status: data.status || "active",
          }
        })

        // Combine and sort all activities
        const allActivities = [...orderActivities, ...customerActivities, ...agentActivities]
          .sort((a, b) => b.timestamp - a.timestamp)
          .slice(0, 5)

        setActivities(allActivities)
      } catch (error) {
        console.error("Error fetching recent activity:", error)
        setActivities([])
      } finally {
        setLoading(false)
      }
    }

    fetchRecentActivity()
  }, [])

  if (loading) {
    return (
      <div className="space-y-4">
        <p className="text-sm text-muted-foreground">Loading recent activity...</p>
      </div>
    )
  }

  if (activities.length === 0) {
    return (
      <div className="space-y-4">
        <p className="text-sm text-muted-foreground">No recent activity found</p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {activities.map((activity) => (
        <div key={activity.id} className="flex items-center">
          <div className={`h-2 w-2 rounded-full mr-2 ${getStatusColor(activity.status)}`} />
          <div className="space-y-1">
            <p className="text-sm font-medium leading-none">{activity.description}</p>
            <p className="text-xs text-muted-foreground">
              {formatDistanceToNow(activity.timestamp, { addSuffix: true })}
            </p>
          </div>
        </div>
      ))}
    </div>
  )
}

function getStatusColor(status) {
  switch (status) {
    case "completed":
      return "bg-green-500"
    case "pending":
      return "bg-yellow-500"
    case "active":
      return "bg-blue-500"
    case "inactive":
      return "bg-gray-500"
    default:
      return "bg-gray-300"
  }
}

