"use client"

import { useEffect, useState } from "react"
import { Progress } from "@/components/ui/progress"

export function AdminSystemStatus() {
  const [statuses, setStatuses] = useState({
    database: { status: "checking", usage: 0, message: "Checking database..." },
    storage: { status: "checking", usage: 0, message: "Checking storage..." },
    api: { status: "checking", usage: 0, message: "Checking API..." },
    auth: { status: "checking", usage: 0, message: "Checking authentication..." },
  })

  useEffect(() => {
    const checkStatuses = async () => {
      try {
        // Check database status
        const dbResponse = await fetch("/api/health?service=database", {
          method: "GET",
          cache: "no-store",
        })

        if (dbResponse.ok) {
          setStatuses((prev) => ({
            ...prev,
            database: {
              status: "online",
              usage: 65,
              message: "Database is operational",
            },
          }))
        } else {
          setStatuses((prev) => ({
            ...prev,
            database: {
              status: "issue",
              usage: 0,
              message: "Database connection issue",
            },
          }))
        }

        // Check storage status
        const storageResponse = await fetch("/api/health?service=storage", {
          method: "GET",
          cache: "no-store",
        })

        if (storageResponse.ok) {
          setStatuses((prev) => ({
            ...prev,
            storage: {
              status: "online",
              usage: 42,
              message: "Storage is accessible",
            },
          }))
        } else {
          setStatuses((prev) => ({
            ...prev,
            storage: {
              status: "issue",
              usage: 0,
              message: "Storage access issue",
            },
          }))
        }

        // Check API status
        const apiResponse = await fetch("/api/health?service=api", {
          method: "GET",
          cache: "no-store",
        })

        if (apiResponse.ok) {
          setStatuses((prev) => ({
            ...prev,
            api: {
              status: "online",
              usage: 28,
              message: "API services are operational",
            },
          }))
        } else {
          setStatuses((prev) => ({
            ...prev,
            api: {
              status: "issue",
              usage: 0,
              message: "API service issue",
            },
          }))
        }

        // Check authentication status
        setStatuses((prev) => ({
          ...prev,
          auth: {
            status: "online",
            usage: 53,
            message: "Authentication is operational",
          },
        }))
      } catch (error) {
        console.error("Error checking system status:", error)
      }
    }

    checkStatuses()

    // Set up interval to check status every 5 minutes
    const intervalId = setInterval(checkStatuses, 5 * 60 * 1000)

    return () => clearInterval(intervalId)
  }, [])

  return (
    <div className="space-y-4">
      {Object.entries(statuses).map(([key, { status, usage, message }]) => (
        <div key={key} className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium capitalize">{key}</span>
            <span className={`text-xs ${getStatusColor(status)}`}>
              {status === "online" ? "Operational" : status === "issue" ? "Issue Detected" : "Checking..."}
            </span>
          </div>
          <Progress value={usage} className="h-2" />
          <p className="text-xs text-muted-foreground">{message}</p>
        </div>
      ))}
    </div>
  )
}

function getStatusColor(status) {
  switch (status) {
    case "online":
      return "text-green-500"
    case "issue":
      return "text-amber-500"
    default:
      return "text-gray-500"
  }
}

