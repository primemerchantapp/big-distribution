"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Search, Download, Calendar, ArrowUpDown, Loader2 } from "lucide-react"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Calendar as CalendarComponent } from "@/components/ui/calendar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ref, get, query, orderByChild, limitToLast } from "firebase/database"
import { db } from "@/lib/firebase"
import { useToast } from "@/hooks/use-toast"

export function AuditLogsManagement() {
  const [searchQuery, setSearchQuery] = useState("")
  const [date, setDate] = useState<Date | undefined>(new Date())
  const [auditLogs, setAuditLogs] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const { toast } = useToast()

  useEffect(() => {
    const fetchAuditLogs = async () => {
      try {
        setIsLoading(true)

        // Fetch audit logs from Firebase
        // Note: In a real app, you would have an audit_logs collection
        // For now, we'll use a combination of user activity and system events

        // Fetch user logins
        const usersRef = ref(db, "users")
        const usersSnapshot = await get(usersRef)

        // Fetch orders for order-related activities
        const ordersRef = ref(db, "orders")
        const ordersQuery = query(ordersRef, orderByChild("order_date"), limitToLast(20))
        const ordersSnapshot = await get(ordersQuery)

        // Fetch customer updates
        const customersRef = ref(db, "customers")
        const customersSnapshot = await get(customersRef)

        const logs = []

        // Process user login activities
        if (usersSnapshot.exists()) {
          const usersData = usersSnapshot.val()
          Object.entries(usersData).forEach(([id, data]: [string, any]) => {
            if (data.last_login) {
              logs.push({
                id: `LOGIN-${id}`,
                timestamp: data.last_login || "Unknown",
                user: data.email || "Unknown User",
                action: "LOGIN",
                resource: "Admin Portal",
                ipAddress: data.last_ip || "Unknown",
                status: "SUCCESS",
                details: "User login successful",
              })
            }
          })
        }

        // Process order activities
        if (ordersSnapshot.exists()) {
          const ordersData = ordersSnapshot.val()
          Object.entries(ordersData).forEach(([id, data]: [string, any]) => {
            logs.push({
              id: `ORDER-${id}`,
              timestamp: data.order_date || "Unknown",
              user: data.created_by || "System",
              action: "CREATE",
              resource: "Order",
              ipAddress: "System",
              status: "SUCCESS",
              details: `Created order for ${data.customer_name || "Unknown Customer"}`,
            })
          })
        }

        // Process customer activities
        if (customersSnapshot.exists()) {
          const customersData = customersSnapshot.val()
          Object.entries(customersData)
            .slice(0, 10)
            .forEach(([id, data]: [string, any]) => {
              logs.push({
                id: `CUST-${id}`,
                timestamp: data.created_at || data.updated_at || "Unknown",
                user: data.created_by || "System",
                action: "UPDATE",
                resource: "Customer",
                ipAddress: "System",
                status: "SUCCESS",
                details: `Updated customer information for ${data.name || "Unknown Customer"}`,
              })
            })
        }

        // Add some system activities
        logs.push({
          id: "SYS-001",
          timestamp: new Date().toISOString(),
          user: "system",
          action: "BACKUP",
          resource: "Database",
          ipAddress: "localhost",
          status: "SUCCESS",
          details: "Automated system backup completed",
        })

        logs.push({
          id: "SYS-002",
          timestamp: new Date(Date.now() - 86400000).toISOString(), // 1 day ago
          user: "system",
          action: "MAINTENANCE",
          resource: "System",
          ipAddress: "localhost",
          status: "SUCCESS",
          details: "System maintenance completed",
        })

        // Sort logs by timestamp (newest first)
        logs.sort((a, b) => {
          return new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
        })

        setAuditLogs(logs)
      } catch (error) {
        console.error("Error fetching audit logs:", error)
        toast({
          title: "Error",
          description: "Failed to load audit logs",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    fetchAuditLogs()
  }, [toast])

  const getStatusColor = (status: string) => {
    switch (status) {
      case "SUCCESS":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
      case "FAILED":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300"
      case "WARNING":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300"
    }
  }

  const getActionColor = (action: string) => {
    switch (action) {
      case "CREATE":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300"
      case "UPDATE":
        return "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300"
      case "DELETE":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300"
      case "LOGIN":
      case "LOGOUT":
        return "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300"
      case "VIEW":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
      case "BACKUP":
      case "MAINTENANCE":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300"
    }
  }

  const filteredLogs = auditLogs.filter(
    (log) =>
      log.user.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.action.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.resource.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.details.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin mr-2" />
        <span>Loading audit logs...</span>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <div className="relative w-full sm:w-64">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search logs..."
              className="w-full pl-8"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" size="icon">
                <Calendar className="h-4 w-4" />
                <span className="sr-only">Pick a date</span>
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="end">
              <CalendarComponent mode="single" selected={date} onSelect={setDate} initialFocus />
            </PopoverContent>
          </Popover>
          <Select defaultValue="all">
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Filter by action" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Actions</SelectItem>
              <SelectItem value="create">Create</SelectItem>
              <SelectItem value="update">Update</SelectItem>
              <SelectItem value="delete">Delete</SelectItem>
              <SelectItem value="login">Login/Logout</SelectItem>
              <SelectItem value="view">View</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <Button variant="outline">
          <Download className="mr-2 h-4 w-4" />
          Export Logs
        </Button>
      </div>

      <Card>
        <CardHeader className="p-4">
          <CardTitle>System Audit Logs</CardTitle>
          <CardDescription>Comprehensive record of all system activities and user actions.</CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[80px]">ID</TableHead>
                <TableHead>
                  <div className="flex items-center gap-1">
                    Timestamp
                    <ArrowUpDown className="h-3 w-3" />
                  </div>
                </TableHead>
                <TableHead>User</TableHead>
                <TableHead>Action</TableHead>
                <TableHead>Resource</TableHead>
                <TableHead>IP Address</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="w-[300px]">Details</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredLogs.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={8} className="h-24 text-center">
                    No audit logs found.
                  </TableCell>
                </TableRow>
              ) : (
                filteredLogs.map((log) => (
                  <TableRow key={log.id}>
                    <TableCell className="font-medium">{log.id}</TableCell>
                    <TableCell>{log.timestamp}</TableCell>
                    <TableCell>{log.user}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className={getActionColor(log.action)}>
                        {log.action}
                      </Badge>
                    </TableCell>
                    <TableCell>{log.resource}</TableCell>
                    <TableCell>{log.ipAddress}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className={getStatusColor(log.status)}>
                        {log.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="max-w-[300px] truncate" title={log.details}>
                      {log.details}
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Logs</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{auditLogs.length}</div>
            <p className="text-xs text-muted-foreground">For the selected period</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Success Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {auditLogs.length > 0
                ? Math.round((auditLogs.filter((log) => log.status === "SUCCESS").length / auditLogs.length) * 100)
                : 0}
              %
            </div>
            <p className="text-xs text-muted-foreground">Operations completed successfully</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Failed Operations</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{auditLogs.filter((log) => log.status === "FAILED").length}</div>
            <p className="text-xs text-muted-foreground">Operations that failed</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Unique Users</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{new Set(auditLogs.map((log) => log.user)).size}</div>
            <p className="text-xs text-muted-foreground">Active in the system</p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

