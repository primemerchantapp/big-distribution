"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { ArrowLeft, Calendar, Check, Package, Pencil, Truck, User } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"

interface AdminOrderDetailsProps {
  id: string
}

// This would typically come from your database
const mockOrderData = {
  id: "ORD-1234",
  customer: {
    id: "CUST-5678",
    name: "Jane Smith",
    email: "jane.smith@example.com",
    phone: "(555) 123-4567",
  },
  agent: {
    id: "AGENT-9012",
    name: "Michael Johnson",
  },
  status: "In Progress",
  date: "2023-03-15",
  items: [
    { id: "ITEM-1", name: "Product A", quantity: 2, price: 29.99 },
    { id: "ITEM-2", name: "Product B", quantity: 1, price: 49.99 },
  ],
  shipping: {
    address: "123 Main St, Anytown, CA 12345",
    method: "Standard Shipping",
    trackingNumber: "TRK-9876543",
  },
  payment: {
    method: "Credit Card",
    total: 109.97,
    status: "Paid",
  },
  notes: "Please leave package at the front door",
}

export function AdminOrderDetails({ id }: AdminOrderDetailsProps) {
  const router = useRouter()
  const [order, setOrder] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [editingStatus, setEditingStatus] = useState(false)
  const [newStatus, setNewStatus] = useState("")

  useEffect(() => {
    // In a real app, you would fetch the order data from your API
    // For this example, we'll use mock data
    setTimeout(() => {
      setOrder(mockOrderData)
      setNewStatus(mockOrderData.status)
      setLoading(false)
    }, 500)
  }, [id])

  if (loading) {
    return <div>Loading order details...</div>
  }

  if (!order) {
    return <div>Order not found</div>
  }

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case "completed":
        return "bg-green-500"
      case "in progress":
        return "bg-blue-500"
      case "pending":
        return "bg-yellow-500"
      case "cancelled":
        return "bg-red-500"
      default:
        return "bg-gray-500"
    }
  }

  const handleStatusUpdate = () => {
    // In a real app, you would update the order status in your database
    setOrder({ ...order, status: newStatus })
    setEditingStatus(false)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="outline" size="icon" onClick={() => router.back()}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div>
          <h3 className="text-lg font-medium">Order #{order.id}</h3>
          <p className="text-sm text-muted-foreground">Placed on {order.date}</p>
        </div>
        <div className="ml-auto flex items-center gap-2">
          {editingStatus ? (
            <div className="flex items-center gap-2">
              <Select value={newStatus} onValueChange={setNewStatus}>
                <SelectTrigger className="w-[150px]">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Pending">Pending</SelectItem>
                  <SelectItem value="In Progress">In Progress</SelectItem>
                  <SelectItem value="Completed">Completed</SelectItem>
                  <SelectItem value="Cancelled">Cancelled</SelectItem>
                </SelectContent>
              </Select>
              <Button size="sm" onClick={handleStatusUpdate}>
                <Check className="h-4 w-4 mr-1" />
                Save
              </Button>
              <Button size="sm" variant="outline" onClick={() => setEditingStatus(false)}>
                Cancel
              </Button>
            </div>
          ) : (
            <>
              <Badge className={getStatusColor(order.status)}>{order.status}</Badge>
              <Button size="sm" variant="outline" onClick={() => setEditingStatus(true)}>
                <Pencil className="h-4 w-4 mr-1" />
                Edit Status
              </Button>
            </>
          )}
        </div>
      </div>

      <Tabs defaultValue="details">
        <TabsList>
          <TabsTrigger value="details">Order Details</TabsTrigger>
          <TabsTrigger value="customer">Customer</TabsTrigger>
          <TabsTrigger value="shipping">Shipping</TabsTrigger>
          <TabsTrigger value="payment">Payment</TabsTrigger>
        </TabsList>
        <TabsContent value="details" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Package className="h-5 w-5" />
                Order Items
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {order.items.map((item: any) => (
                  <div key={item.id} className="flex items-center justify-between border-b pb-2">
                    <div>
                      <p className="font-medium">{item.name}</p>
                      <p className="text-sm text-muted-foreground">Quantity: {item.quantity}</p>
                    </div>
                    <p className="font-medium">${item.price.toFixed(2)}</p>
                  </div>
                ))}
                <div className="flex items-center justify-between pt-2">
                  <p className="font-bold">Total</p>
                  <p className="font-bold">${order.payment.total.toFixed(2)}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Assigned Agent</CardTitle>
              <CardDescription>The agent responsible for this order</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">{order.agent.name}</p>
                  <p className="text-sm text-muted-foreground">Agent ID: {order.agent.id}</p>
                </div>
                <Button variant="outline" onClick={() => router.push(`/admin/agents/${order.agent.id}`)}>
                  View Agent
                </Button>
              </div>
            </CardContent>
          </Card>

          {order.notes && (
            <Card>
              <CardHeader>
                <CardTitle>Notes</CardTitle>
              </CardHeader>
              <CardContent>
                <p>{order.notes}</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="customer">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="h-5 w-5" />
                Customer Information
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <p>
                  <span className="font-medium">Name:</span> {order.customer.name}
                </p>
                <p>
                  <span className="font-medium">Email:</span> {order.customer.email}
                </p>
                <p>
                  <span className="font-medium">Phone:</span> {order.customer.phone}
                </p>
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="outline" onClick={() => router.push(`/admin/customers/${order.customer.id}`)}>
                View Customer
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="shipping">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Truck className="h-5 w-5" />
                Shipping Details
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <p>
                  <span className="font-medium">Address:</span> {order.shipping.address}
                </p>
                <p>
                  <span className="font-medium">Method:</span> {order.shipping.method}
                </p>
                <p>
                  <span className="font-medium">Tracking Number:</span> {order.shipping.trackingNumber}
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="payment">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Payment Information
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <p>
                  <span className="font-medium">Method:</span> {order.payment.method}
                </p>
                <p>
                  <span className="font-medium">Total:</span> ${order.payment.total.toFixed(2)}
                </p>
                <p>
                  <span className="font-medium">Status:</span> {order.payment.status}
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="flex justify-end gap-2">
        <Button variant="outline">Print Order</Button>
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button variant="destructive">Cancel Order</Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Are you sure?</AlertDialogTitle>
              <AlertDialogDescription>
                This action cannot be undone. This will cancel the order and notify the customer.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>No, keep order</AlertDialogCancel>
              <AlertDialogAction>Yes, cancel order</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </div>
  )
}

