"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Search, Plus, MoreHorizontal, Check, X, Loader2 } from "lucide-react"
import { Switch } from "@/components/ui/switch"
import { ref, get } from "firebase/database"
import { db } from "@/lib/firebase"
import { useToast } from "@/hooks/use-toast"

export function PermissionsManagement() {
  const [searchQuery, setSearchQuery] = useState("")
  const [roles, setRoles] = useState<any[]>([])
  const [permissions, setPermissions] = useState<any[]>([])
  const [users, setUsers] = useState<any[]>([])
  const [rolePermissionMatrix, setRolePermissionMatrix] = useState<Record<string, string[]>>({})
  const [isLoading, setIsLoading] = useState(true)
  const { toast } = useToast()

  useEffect(() => {
    const fetchData = async () => {
      try {
        setIsLoading(true)

        // Fetch users
        const usersRef = ref(db, "users")
        const usersSnapshot = await get(usersRef)

        // Fetch roles (in a real app, you would have a roles collection)
        // For now, we'll create some default roles
        const defaultRoles = [
          {
            id: "ROLE001",
            name: "Administrator",
            description: "Full system access with all permissions",
            userCount: 0,
            isSystem: true,
          },
          {
            id: "ROLE002",
            name: "Sales Manager",
            description: "Manage sales, orders, and sales team",
            userCount: 0,
            isSystem: true,
          },
          {
            id: "ROLE003",
            name: "Sales Agent",
            description: "Create and manage orders and customers",
            userCount: 0,
            isSystem: true,
          },
          {
            id: "ROLE004",
            name: "Inventory Manager",
            description: "Manage products and inventory",
            userCount: 0,
            isSystem: true,
          },
          {
            id: "ROLE005",
            name: "Customer Support",
            description: "View orders and customer information",
            userCount: 0,
            isSystem: true,
          },
        ]

        // Create default permissions
        const defaultPermissions = [
          {
            id: "PERM001",
            name: "View Dashboard",
            description: "Access to view the main dashboard",
            category: "Dashboard",
          },
          {
            id: "PERM002",
            name: "Manage Products",
            description: "Create, edit, and delete products",
            category: "Products",
          },
          {
            id: "PERM003",
            name: "View Products",
            description: "View product information",
            category: "Products",
          },
          {
            id: "PERM004",
            name: "Manage Inventory",
            description: "Update inventory levels and settings",
            category: "Inventory",
          },
          {
            id: "PERM005",
            name: "View Inventory",
            description: "View inventory levels",
            category: "Inventory",
          },
          {
            id: "PERM006",
            name: "Manage Orders",
            description: "Create, edit, and process orders",
            category: "Orders",
          },
          {
            id: "PERM007",
            name: "View Orders",
            description: "View order information",
            category: "Orders",
          },
          {
            id: "PERM008",
            name: "Manage Customers",
            description: "Create, edit, and delete customer records",
            category: "Customers",
          },
          {
            id: "PERM009",
            name: "View Customers",
            description: "View customer information",
            category: "Customers",
          },
          {
            id: "PERM010",
            name: "Manage Agents",
            description: "Create, edit, and delete agent accounts",
            category: "Agents",
          },
          {
            id: "PERM011",
            name: "View Reports",
            description: "Access to view reports and analytics",
            category: "Reports",
          },
          {
            id: "PERM012",
            name: "Export Reports",
            description: "Export reports and data",
            category: "Reports",
          },
          {
            id: "PERM013",
            name: "View Audit Logs",
            description: "Access to view system audit logs",
            category: "System",
          },
          {
            id: "PERM014",
            name: "Manage System Settings",
            description: "Configure system-wide settings",
            category: "System",
          },
          {
            id: "PERM015",
            name: "Manage Roles & Permissions",
            description: "Create, edit, and assign roles and permissions",
            category: "System",
          },
        ]

        // Create default role-permission matrix
        const defaultRolePermissionMatrix: Record<string, string[]> = {
          ROLE001: defaultPermissions.map((p) => p.id), // Admin has all permissions
          ROLE002: [
            "PERM001",
            "PERM002",
            "PERM003",
            "PERM004",
            "PERM005",
            "PERM006",
            "PERM007",
            "PERM008",
            "PERM009",
            "PERM010",
            "PERM011",
            "PERM012",
          ],
          ROLE003: ["PERM001", "PERM003", "PERM005", "PERM006", "PERM007", "PERM008", "PERM009"],
          ROLE004: ["PERM001", "PERM002", "PERM003", "PERM004", "PERM005", "PERM011"],
          ROLE005: ["PERM001", "PERM003", "PERM005", "PERM007", "PERM009"],
        }

        // Process users data
        const formattedUsers = []
        if (usersSnapshot.exists()) {
          const usersData = usersSnapshot.val()

          // Count users per role and format user data
          Object.entries(usersData).forEach(([id, data]: [string, any]) => {
            const roleId = data.role || "ROLE003" // Default to Sales Agent if no role

            // Increment user count for this role
            const roleIndex = defaultRoles.findIndex((r) => r.id === roleId)
            if (roleIndex !== -1) {
              defaultRoles[roleIndex].userCount++
            }

            formattedUsers.push({
              id,
              name: data.name || "Unknown User",
              email: data.email || "No email",
              role: roleId,
              status: data.status || "Active",
              lastLogin: data.last_login || "Never",
            })
          })
        }

        setRoles(defaultRoles)
        setPermissions(defaultPermissions)
        setUsers(formattedUsers)
        setRolePermissionMatrix(defaultRolePermissionMatrix)
      } catch (error) {
        console.error("Error fetching permissions data:", error)
        toast({
          title: "Error",
          description: "Failed to load permissions data",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    fetchData()
  }, [toast])

  const filteredRoles = roles.filter(
    (role) =>
      role.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      role.description.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const filteredPermissions = permissions.filter(
    (permission) =>
      permission.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      permission.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      permission.category.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const filteredUsers = users.filter(
    (user) =>
      user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      roles
        .find((r) => r.id === user.role)
        ?.name.toLowerCase()
        .includes(searchQuery.toLowerCase()),
  )

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Active":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
      case "Inactive":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300"
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin mr-2" />
        <span>Loading permissions data...</span>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <Tabs defaultValue="roles" className="w-full">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <TabsList>
            <TabsTrigger value="roles">Roles</TabsTrigger>
            <TabsTrigger value="permissions">Permissions</TabsTrigger>
            <TabsTrigger value="matrix">Role-Permission Matrix</TabsTrigger>
            <TabsTrigger value="users">User Assignments</TabsTrigger>
          </TabsList>
          <div className="flex w-full sm:w-auto items-center gap-2">
            <div className="relative w-full sm:w-64">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search..."
                className="w-full pl-8"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Add New
            </Button>
          </div>
        </div>

        <TabsContent value="roles" className="mt-4">
          <Card>
            <CardHeader className="p-4">
              <CardTitle>System Roles</CardTitle>
              <CardDescription>Manage roles that define sets of permissions for users.</CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[100px]">ID</TableHead>
                    <TableHead>Role Name</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead className="text-center">Users</TableHead>
                    <TableHead className="text-center">System Role</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredRoles.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={6} className="h-24 text-center">
                        No roles found.
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredRoles.map((role) => (
                      <TableRow key={role.id}>
                        <TableCell className="font-medium">{role.id}</TableCell>
                        <TableCell>{role.name}</TableCell>
                        <TableCell>{role.description}</TableCell>
                        <TableCell className="text-center">{role.userCount}</TableCell>
                        <TableCell className="text-center">
                          {role.isSystem ? (
                            <Check className="h-4 w-4 mx-auto text-green-600" />
                          ) : (
                            <X className="h-4 w-4 mx-auto text-muted-foreground" />
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreHorizontal className="h-4 w-4" />
                                <span className="sr-only">Actions</span>
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>Actions</DropdownMenuLabel>
                              <DropdownMenuItem>Edit Role</DropdownMenuItem>
                              <DropdownMenuItem>View Permissions</DropdownMenuItem>
                              <DropdownMenuItem>View Users</DropdownMenuItem>
                              <DropdownMenuSeparator />
                              {!role.isSystem && (
                                <DropdownMenuItem className="text-red-600">Delete Role</DropdownMenuItem>
                              )}
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="permissions" className="mt-4">
          <Card>
            <CardHeader className="p-4">
              <CardTitle>System Permissions</CardTitle>
              <CardDescription>Individual permissions that can be assigned to roles.</CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[100px]">ID</TableHead>
                    <TableHead>Permission Name</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredPermissions.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={5} className="h-24 text-center">
                        No permissions found.
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredPermissions.map((permission) => (
                      <TableRow key={permission.id}>
                        <TableCell className="font-medium">{permission.id}</TableCell>
                        <TableCell>{permission.name}</TableCell>
                        <TableCell>{permission.description}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{permission.category}</Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button variant="outline" size="sm">
                            Edit
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="matrix" className="mt-4">
          <Card>
            <CardHeader className="p-4">
              <CardTitle>Role-Permission Matrix</CardTitle>
              <CardDescription>Configure which permissions are assigned to each role.</CardDescription>
            </CardHeader>
            <CardContent className="p-0 overflow-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="sticky left-0 bg-background">Role / Permission</TableHead>
                    {permissions.map((permission) => (
                      <TableHead key={permission.id} className="text-center min-w-[120px]">
                        {permission.name}
                      </TableHead>
                    ))}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {roles.map((role) => (
                    <TableRow key={role.id}>
                      <TableCell className="font-medium sticky left-0 bg-background">{role.name}</TableCell>
                      {permissions.map((permission) => (
                        <TableCell key={`${role.id}-${permission.id}`} className="text-center">
                          <Switch
                            checked={rolePermissionMatrix[role.id]?.includes(permission.id) || false}
                            onCheckedChange={() => {}}
                            aria-label={`${role.name} - ${permission.name}`}
                          />
                        </TableCell>
                      ))}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="users" className="mt-4">
          <Card>
            <CardHeader className="p-4">
              <CardTitle>User Role Assignments</CardTitle>
              <CardDescription>Manage which roles are assigned to each user.</CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[100px]">ID</TableHead>
                    <TableHead>User Name</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Assigned Role</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Last Login</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredUsers.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={7} className="h-24 text-center">
                        No users found.
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredUsers.map((user) => (
                      <TableRow key={user.id}>
                        <TableCell className="font-medium">{user.id.substring(0, 8)}</TableCell>
                        <TableCell>{user.name}</TableCell>
                        <TableCell>{user.email}</TableCell>
                        <TableCell>{roles.find((r) => r.id === user.role)?.name || "Unknown Role"}</TableCell>
                        <TableCell>
                          <Badge variant="outline" className={getStatusColor(user.status)}>
                            {user.status}
                          </Badge>
                        </TableCell>
                        <TableCell>{user.lastLogin}</TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreHorizontal className="h-4 w-4" />
                                <span className="sr-only">Actions</span>
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>Actions</DropdownMenuLabel>
                              <DropdownMenuItem>Change Role</DropdownMenuItem>
                              <DropdownMenuItem>View Permissions</DropdownMenuItem>
                              <DropdownMenuSeparator />
                              {user.status === "Active" ? (
                                <DropdownMenuItem>Deactivate User</DropdownMenuItem>
                              ) : (
                                <DropdownMenuItem>Activate User</DropdownMenuItem>
                              )}
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

