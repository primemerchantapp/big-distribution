"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"
import { Loader2, Save } from "lucide-react"
import { getAdminSettings, updateAdminSettings, type AdminSettings } from "@/lib/settings-utils"

export function AdminSettingsForm() {
  const [isLoading, setIsLoading] = useState(true)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { toast } = useToast()
  const [settings, setSettings] = useState<AdminSettings | null>(null)

  useEffect(() => {
    const fetchSettings = async () => {
      try {
        setIsLoading(true)
        const adminSettings = await getAdminSettings()
        setSettings(adminSettings)
      } catch (error) {
        console.error("Error fetching admin settings:", error)
        toast({
          title: "Error",
          description: "Failed to load admin settings. Please try again.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    fetchSettings()
  }, [toast])

  const handleSystemChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    if (!settings) return

    const { name, value } = e.target
    setSettings({
      ...settings,
      system: {
        ...settings.system,
        [name]: value,
      },
    })
  }

  const handleSystemNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!settings) return

    const { name, value } = e.target
    setSettings({
      ...settings,
      system: {
        ...settings.system,
        [name]: Number.parseInt(value, 10) || 0,
      },
    })
  }

  const handleSystemSwitchChange = (name: string, checked: boolean) => {
    if (!settings) return

    setSettings({
      ...settings,
      system: {
        ...settings.system,
        [name]: checked,
      },
    })
  }

  const handleSystemSelectChange = (name: string, value: string) => {
    if (!settings) return

    setSettings({
      ...settings,
      system: {
        ...settings.system,
        [name]: value,
      },
    })
  }

  const handleNotificationChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    if (!settings) return

    const { name, value } = e.target
    setSettings({
      ...settings,
      notifications: {
        ...settings.notifications,
        [name]: value,
      },
    })
  }

  const handleNotificationSwitchChange = (name: string, checked: boolean) => {
    if (!settings) return

    setSettings({
      ...settings,
      notifications: {
        ...settings.notifications,
        [name]: checked,
      },
    })
  }

  const handleAppearanceChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    if (!settings) return

    const { name, value } = e.target
    setSettings({
      ...settings,
      appearance: {
        ...settings.appearance,
        [name]: value,
      },
    })
  }

  const handleAppearanceSwitchChange = (name: string, checked: boolean) => {
    if (!settings) return

    setSettings({
      ...settings,
      appearance: {
        ...settings.appearance,
        [name]: checked,
      },
    })
  }

  const handleSaveSystemSettings = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!settings) return

    try {
      setIsSubmitting(true)
      await updateAdminSettings("system", settings.system)
      toast({
        title: "Settings Saved",
        description: "Company settings have been updated successfully.",
      })
    } catch (error) {
      console.error("Error saving system settings:", error)
      toast({
        title: "Error",
        description: "Failed to save company settings. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleSaveNotificationSettings = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!settings) return

    try {
      setIsSubmitting(true)
      await updateAdminSettings("notifications", settings.notifications)
      toast({
        title: "Settings Saved",
        description: "Notification settings have been updated successfully.",
      })
    } catch (error) {
      console.error("Error saving notification settings:", error)
      toast({
        title: "Error",
        description: "Failed to save notification settings. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleSaveAppearanceSettings = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!settings) return

    try {
      setIsSubmitting(true)
      await updateAdminSettings("appearance", settings.appearance)
      toast({
        title: "Settings Saved",
        description: "Appearance settings have been updated successfully.",
      })
    } catch (error) {
      console.error("Error saving appearance settings:", error)
      toast({
        title: "Error",
        description: "Failed to save appearance settings. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-6">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  if (!settings) {
    return (
      <div className="p-6">
        <p className="text-center text-muted-foreground">Failed to load settings. Please refresh the page.</p>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="company">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="company">Company Info</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
          <TabsTrigger value="appearance">Appearance</TabsTrigger>
        </TabsList>

        <TabsContent value="company" className="space-y-4 pt-4">
          <form onSubmit={handleSaveSystemSettings}>
            <Card>
              <CardHeader>
                <CardTitle>Company Information</CardTitle>
                <CardDescription>Update your company details and preferences</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="companyName">Company Name</Label>
                    <Input
                      id="companyName"
                      name="companyName"
                      value={settings.system.companyName}
                      onChange={handleSystemChange}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="supportEmail">Support Email</Label>
                    <Input
                      id="supportEmail"
                      name="supportEmail"
                      type="email"
                      value={settings.system.supportEmail}
                      onChange={handleSystemChange}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="contactPhone">Contact Phone</Label>
                    <Input
                      id="contactPhone"
                      name="contactPhone"
                      value={settings.system.contactPhone}
                      onChange={handleSystemChange}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="maxAgents">Maximum Number of Agents</Label>
                    <Input
                      id="maxAgents"
                      name="maxAgents"
                      type="number"
                      value={settings.system.maxAgents}
                      onChange={handleSystemNumberChange}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="maxCustomersPerAgent">Max Customers Per Agent</Label>
                    <Input
                      id="maxCustomersPerAgent"
                      name="maxCustomersPerAgent"
                      type="number"
                      value={settings.system.maxCustomersPerAgent}
                      onChange={handleSystemNumberChange}
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Allow Agent Registration</Label>
                    <p className="text-sm text-muted-foreground">Let new agents sign up on their own</p>
                  </div>
                  <Switch
                    checked={settings.system.enableRegistration}
                    onCheckedChange={(checked) => handleSystemSwitchChange("enableRegistration", checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Require Admin Approval</Label>
                    <p className="text-sm text-muted-foreground">New agents need your approval before they can start</p>
                  </div>
                  <Switch
                    checked={settings.system.requireApproval}
                    onCheckedChange={(checked) => handleSystemSwitchChange("requireApproval", checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Track Agent Locations</Label>
                    <p className="text-sm text-muted-foreground">See where your agents are during work hours</p>
                  </div>
                  <Switch
                    checked={settings.system.enableLocationTracking}
                    onCheckedChange={(checked) => handleSystemSwitchChange("enableLocationTracking", checked)}
                  />
                </div>
              </CardContent>
            </Card>

            <Card className="mt-4">
              <CardHeader>
                <CardTitle>Map Settings</CardTitle>
                <CardDescription>Configure how maps appear in your application</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="mapApiKey">Google Maps API Key</Label>
                  <Input
                    id="mapApiKey"
                    name="mapApiKey"
                    value={settings.system.mapApiKey}
                    onChange={handleSystemChange}
                  />
                  <p className="text-xs text-muted-foreground">This is needed for the map to work properly</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="defaultMapCenter">Default Map Center (lat, lng)</Label>
                    <Input
                      id="defaultMapCenter"
                      name="defaultMapCenter"
                      value={settings.system.defaultMapCenter}
                      onChange={handleSystemChange}
                    />
                    <p className="text-xs text-muted-foreground">Example: 12.8797, 121.774 for Philippines</p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="defaultMapZoom">Default Map Zoom Level</Label>
                    <Input
                      id="defaultMapZoom"
                      name="defaultMapZoom"
                      type="number"
                      min="1"
                      max="20"
                      value={settings.system.defaultMapZoom}
                      onChange={handleSystemNumberChange}
                    />
                    <p className="text-xs text-muted-foreground">Higher number = more zoomed in (1-20)</p>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Map Style</Label>
                  <Select
                    value={settings.system.mapType}
                    onValueChange={(value) => handleSystemSelectChange("mapType", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select map style" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="roadmap">Standard Road Map</SelectItem>
                      <SelectItem value="satellite">Satellite View</SelectItem>
                      <SelectItem value="hybrid">Hybrid (Satellite + Roads)</SelectItem>
                      <SelectItem value="terrain">Terrain View</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            <div className="mt-4 flex justify-end">
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Saving...
                  </>
                ) : (
                  <>
                    <Save className="mr-2 h-4 w-4" />
                    Save Company Settings
                  </>
                )}
              </Button>
            </div>
          </form>
        </TabsContent>

        <TabsContent value="notifications" className="space-y-4 pt-4">
          <form onSubmit={handleSaveNotificationSettings}>
            <Card>
              <CardHeader>
                <CardTitle>Notification Settings</CardTitle>
                <CardDescription>Choose how you want to be notified</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Email Notifications</Label>
                    <p className="text-sm text-muted-foreground">Send updates via email</p>
                  </div>
                  <Switch
                    checked={settings.notifications.enableEmailNotifications}
                    onCheckedChange={(checked) => handleNotificationSwitchChange("enableEmailNotifications", checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Push Notifications</Label>
                    <p className="text-sm text-muted-foreground">Send notifications to mobile devices</p>
                  </div>
                  <Switch
                    checked={settings.notifications.enablePushNotifications}
                    onCheckedChange={(checked) => handleNotificationSwitchChange("enablePushNotifications", checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>SMS Notifications</Label>
                    <p className="text-sm text-muted-foreground">Send text messages for important updates</p>
                  </div>
                  <Switch
                    checked={settings.notifications.enableSmsNotifications}
                    onCheckedChange={(checked) => handleNotificationSwitchChange("enableSmsNotifications", checked)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="adminEmailRecipients">Admin Email Recipients</Label>
                  <Input
                    id="adminEmailRecipients"
                    name="adminEmailRecipients"
                    value={settings.notifications.adminEmailRecipients}
                    onChange={handleNotificationChange}
                  />
                  <p className="text-xs text-muted-foreground">
                    Who should receive admin notifications? (separate multiple emails with commas)
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="dailyReportTime">Daily Report Time</Label>
                  <Input
                    id="dailyReportTime"
                    name="dailyReportTime"
                    type="time"
                    value={settings.notifications.dailyReportTime}
                    onChange={handleNotificationChange}
                  />
                  <p className="text-xs text-muted-foreground">When should daily summary reports be sent?</p>
                </div>

                <div className="space-y-2 pt-4">
                  <h3 className="text-sm font-medium">What would you like to be notified about?</h3>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="notifyOnNewCustomer">New Customer Registration</Label>
                    <Switch
                      id="notifyOnNewCustomer"
                      checked={settings.notifications.notifyOnNewCustomer}
                      onCheckedChange={(checked) => handleNotificationSwitchChange("notifyOnNewCustomer", checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="notifyOnNewOrder">New Order Placed</Label>
                    <Switch
                      id="notifyOnNewOrder"
                      checked={settings.notifications.notifyOnNewOrder}
                      onCheckedChange={(checked) => handleNotificationSwitchChange("notifyOnNewOrder", checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="notifyOnAgentRegistration">New Agent Registration</Label>
                    <Switch
                      id="notifyOnAgentRegistration"
                      checked={settings.notifications.notifyOnAgentRegistration}
                      onCheckedChange={(checked) =>
                        handleNotificationSwitchChange("notifyOnAgentRegistration", checked)
                      }
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="mt-4 flex justify-end">
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Saving...
                  </>
                ) : (
                  <>
                    <Save className="mr-2 h-4 w-4" />
                    Save Notification Settings
                  </>
                )}
              </Button>
            </div>
          </form>
        </TabsContent>

        <TabsContent value="appearance" className="space-y-4 pt-4">
          <form onSubmit={handleSaveAppearanceSettings}>
            <Card>
              <CardHeader>
                <CardTitle>Appearance Settings</CardTitle>
                <CardDescription>Customize how your application looks</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="logoUrl">Company Logo URL</Label>
                  <Input
                    id="logoUrl"
                    name="logoUrl"
                    placeholder="https://example.com/logo.png"
                    value={settings.appearance.logoUrl}
                    onChange={handleAppearanceChange}
                  />
                  <p className="text-xs text-muted-foreground">Enter the web address of your company logo image</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="primaryColor">Primary Color</Label>
                  <div className="flex gap-2">
                    <Input
                      id="primaryColor"
                      name="primaryColor"
                      value={settings.appearance.primaryColor}
                      onChange={handleAppearanceChange}
                    />
                    <div
                      className="h-10 w-10 rounded border"
                      style={{ backgroundColor: settings.appearance.primaryColor }}
                    />
                  </div>
                  <p className="text-xs text-muted-foreground">Enter a hex color code (e.g., #4f46e5)</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="companyTagline">Company Tagline</Label>
                  <Input
                    id="companyTagline"
                    name="companyTagline"
                    value={settings.appearance.companyTagline}
                    onChange={handleAppearanceChange}
                  />
                  <p className="text-xs text-muted-foreground">A short slogan that appears on the login page</p>
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Show Welcome Message</Label>
                    <p className="text-sm text-muted-foreground">Display a welcome message to users</p>
                  </div>
                  <Switch
                    checked={settings.appearance.showWelcomeMessage}
                    onCheckedChange={(checked) => handleAppearanceSwitchChange("showWelcomeMessage", checked)}
                  />
                </div>

                {settings.appearance.showWelcomeMessage && (
                  <div className="space-y-2">
                    <Label htmlFor="welcomeMessage">Welcome Message</Label>
                    <Textarea
                      id="welcomeMessage"
                      name="welcomeMessage"
                      value={settings.appearance.welcomeMessage}
                      onChange={handleAppearanceChange}
                      rows={3}
                    />
                  </div>
                )}
              </CardContent>
            </Card>

            <div className="mt-4 flex justify-end">
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Saving...
                  </>
                ) : (
                  <>
                    <Save className="mr-2 h-4 w-4" />
                    Save Appearance Settings
                  </>
                )}
              </Button>
            </div>
          </form>
        </TabsContent>
      </Tabs>
    </div>
  )
}

