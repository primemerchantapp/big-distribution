"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { collection, getDocs, query, where } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { useAuth } from "@/lib/auth-context"

export function AgentsMap() {
  const { user } = useAuth()
  const [agentData, setAgentData] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchAgentData = async () => {
      if (!user) return

      try {
        setLoading(true)

        // Fetch agent data
        const agentsQuery = query(collection(db, "agents"), where("id", "==", user.uid))

        const agentsSnapshot = await getDocs(agentsQuery)

        if (!agentsSnapshot.empty) {
          const agentDoc = agentsSnapshot.docs[0]
          const data = agentDoc.data()

          setAgentData({
            id: agentDoc.id,
            name: data.name || "Unknown Agent",
            territory: data.territory || "Unassigned",
            location: data.lastLocation || { lat: 14.5995, lng: 120.9842 }, // Default to Manila if no location
            lastUpdated: data.lastLocationUpdate?.toDate() || new Date(),
            status: data.status || "active",
          })
        } else {
          console.error("Agent data not found")
        }
      } catch (error) {
        console.error("Error fetching agent data:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchAgentData()
  }, [user])

  if (loading) {
    return (
      <div className="flex-1 p-8">
        <Card>
          <CardHeader>
            <CardTitle>Agent Location</CardTitle>
            <CardDescription>Loading agent tracking data...</CardDescription>
          </CardHeader>
          <CardContent className="h-[500px] flex items-center justify-center">
            <p className="text-muted-foreground">Loading map data...</p>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (!agentData) {
    return (
      <div className="flex-1 p-8">
        <Card>
          <CardHeader>
            <CardTitle>Agent Location</CardTitle>
            <CardDescription>Agent tracking information</CardDescription>
          </CardHeader>
          <CardContent className="h-[500px] flex items-center justify-center">
            <p className="text-muted-foreground">No agent data available</p>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="flex-1 p-8">
      <Card>
        <CardHeader>
          <CardTitle>Agent Location</CardTitle>
          <CardDescription>Current location and territory information</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <h3 className="text-lg font-medium">Agent Information</h3>
                <div className="grid grid-cols-2 gap-2">
                  <div className="text-sm font-medium">Name:</div>
                  <div className="text-sm">{agentData.name}</div>

                  <div className="text-sm font-medium">Territory:</div>
                  <div className="text-sm">{agentData.territory}</div>

                  <div className="text-sm font-medium">Status:</div>
                  <div className="text-sm capitalize">{agentData.status}</div>

                  <div className="text-sm font-medium">Last Updated:</div>
                  <div className="text-sm">{new Date(agentData.lastUpdated).toLocaleString()}</div>

                  <div className="text-sm font-medium">Coordinates:</div>
                  <div className="text-sm">
                    {agentData.location.lat.toFixed(6)}, {agentData.location.lng.toFixed(6)}
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <h3 className="text-lg font-medium">Current Location</h3>
                <div className="h-[200px] bg-muted rounded-md flex items-center justify-center">
                  <p className="text-sm text-muted-foreground">Map integration requires Google Maps API key</p>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <h3 className="text-lg font-medium">Territory Overview</h3>
              <div className="h-[200px] bg-muted rounded-md flex items-center justify-center">
                <p className="text-sm text-muted-foreground">Territory map integration requires Google Maps API key</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

