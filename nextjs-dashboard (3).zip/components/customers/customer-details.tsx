"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { ArrowLeft, Mail, MapPin, Phone, User } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"

interface CustomerDetailsProps {
  id: string
}

// This would typically come from your database
const mockCustomerData = {
  id: "CUST-5678",
  name: "Jane Smith",
  email: "jane.smith@example.com",
  phone: "(555) 123-4567",
  address: "123 Main St, Anytown, CA 12345",
  status: "Active",
  joinDate: "2022-06-15",
  orders: [
    { id: "ORD-1234", date: "2023-03-15", total: 109.97, status: "Completed" },
    { id: "ORD-1111", date: "2023-02-20", total: 59.99, status: "Completed" },
    { id: "ORD-0987", date: "2023-01-10", total: 149.95, status: "Completed" },
  ],
  notes: "Prefers email communication. Interested in new product launches.",
}

export function CustomerDetails({ id }: CustomerDetailsProps) {
  const router = useRouter()
  const [customer, setCustomer] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // In a real app, you would fetch the customer data from your API
    // For this example, we'll use mock data
    setTimeout(() => {
      setCustomer(mockCustomerData)
      setLoading(false)
    }, 500)
  }, [id])

  if (loading) {
    return <div>Loading customer details...</div>
  }

  if (!customer) {
    return <div>Customer not found</div>
  }

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case "active":
        return "bg-green-500"
      case "inactive":
        return "bg-yellow-500"
      default:
        return "bg-gray-500"
    }
  }

  const getOrderStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case "completed":
        return "bg-green-500"
      case "in progress":
        return "bg-blue-500"
      case "pending":
        return "bg-yellow-500"
      case "cancelled":
        return "bg-red-500"
      default:
        return "bg-gray-500"
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="outline" size="icon" onClick={() => router.back()}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div>
          <h3 className="text-lg font-medium">{customer.name}</h3>
          <p className="text-sm text-muted-foreground">Customer since {customer.joinDate}</p>
        </div>
        <div className="ml-auto">
          <Badge className={getStatusColor(customer.status)}>{customer.status}</Badge>
        </div>
      </div>

      <Tabs defaultValue="details">
        <TabsList>
          <TabsTrigger value="details">Customer Details</TabsTrigger>
          <TabsTrigger value="orders">Orders</TabsTrigger>
          <TabsTrigger value="notes">Notes</TabsTrigger>
        </TabsList>
        <TabsContent value="details" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="h-5 w-5" />
                Contact Information
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Mail className="h-4 w-4 text-muted-foreground" />
                  <span>{customer.email}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="h-4 w-4 text-muted-foreground" />
                  <span>{customer.phone}</span>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-muted-foreground" />
                  <span>{customer.address}</span>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <div className="flex gap-2">
                <Button variant="outline" onClick={() => (window.location.href = `mailto:${customer.email}`)}>
                  Send Email
                </Button>
                <Button onClick={() => router.push(`/dashboard/customers/edit/${customer.id}`)}>Edit Customer</Button>
              </div>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="orders">
          <Card>
            <CardHeader>
              <CardTitle>Order History</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {customer.orders.length === 0 ? (
                  <p>No orders found for this customer.</p>
                ) : (
                  customer.orders.map((order: any) => (
                    <div
                      key={order.id}
                      className="flex items-center justify-between border-b pb-2 cursor-pointer"
                      onClick={() => router.push(`/dashboard/orders/${order.id}`)}
                    >
                      <div>
                        <p className="font-medium">{order.id}</p>
                        <p className="text-sm text-muted-foreground">{order.date}</p>
                      </div>
                      <div className="flex items-center gap-4">
                        <p className="font-medium">${order.total.toFixed(2)}</p>
                        <Badge className={getOrderStatusColor(order.status)}>{order.status}</Badge>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
            <CardFooter>
              <Button onClick={() => router.push(`/dashboard/orders/create?customer=${customer.id}`)}>
                Create New Order
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="notes">
          <Card>
            <CardHeader>
              <CardTitle>Customer Notes</CardTitle>
            </CardHeader>
            <CardContent>
              <p>{customer.notes || "No notes available for this customer."}</p>
            </CardContent>
            <CardFooter>
              <Button>Update Notes</Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

