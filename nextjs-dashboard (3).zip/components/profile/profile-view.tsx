"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { collection, getDocs, query, where } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { useAuth } from "@/lib/auth-context"

export function ProfileView() {
  const { user } = useAuth()
  const [profileData, setProfileData] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchProfileData = async () => {
      if (!user) return

      try {
        setLoading(true)

        // Fetch agent profile data
        const agentsQuery = query(collection(db, "agents"), where("id", "==", user.uid))

        const agentsSnapshot = await getDocs(agentsQuery)

        if (!agentsSnapshot.empty) {
          const agentDoc = agentsSnapshot.docs[0]
          const data = agentDoc.data()

          setProfileData({
            id: agentDoc.id,
            name: data.name || "Unknown Agent",
            email: data.email || user.email || "",
            phone: data.phone || "",
            territory: data.territory || "Unassigned",
            role: data.role || "Field Agent",
            status: data.status || "active",
            joinDate: data.createdAt?.toDate() || new Date(),
            manager: data.manager || "Unassigned",
            bio: data.bio || "",
            address: data.address || "",
            city: data.city || "",
            region: data.region || "",
            postalCode: data.postalCode || "",
          })
        } else {
          console.error("Agent profile data not found")
        }
      } catch (error) {
        console.error("Error fetching profile data:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchProfileData()
  }, [user])

  if (loading) {
    return (
      <div className="flex-1 p-8">
        <Card>
          <CardHeader>
            <CardTitle>Agent Profile</CardTitle>
            <CardDescription>Loading profile information...</CardDescription>
          </CardHeader>
          <CardContent className="flex items-center justify-center p-8">
            <p className="text-muted-foreground">Loading profile data...</p>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (!profileData) {
    return (
      <div className="flex-1 p-8">
        <Card>
          <CardHeader>
            <CardTitle>Agent Profile</CardTitle>
            <CardDescription>Your personal information</CardDescription>
          </CardHeader>
          <CardContent className="flex items-center justify-center p-8">
            <p className="text-muted-foreground">No profile data available</p>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="flex-1 p-8">
      <Card>
        <CardHeader>
          <CardTitle>Agent Profile</CardTitle>
          <CardDescription>Your personal and territory information</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-8">
            <div className="flex flex-col md:flex-row gap-8 items-start">
              <div className="flex flex-col items-center space-y-2">
                <Avatar className="h-24 w-24">
                  <AvatarImage src={`/placeholder.svg?height=96&width=96`} alt={profileData.name} />
                  <AvatarFallback className="text-2xl">
                    {profileData.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")
                      .toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <Button variant="outline" size="sm">
                  Change Photo
                </Button>
              </div>

              <div className="flex-1 space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground mb-1">Full Name</h3>
                    <p className="text-base">{profileData.name}</p>
                  </div>

                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground mb-1">Email</h3>
                    <p className="text-base">{profileData.email}</p>
                  </div>

                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground mb-1">Phone</h3>
                    <p className="text-base">{profileData.phone || "Not provided"}</p>
                  </div>

                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground mb-1">Role</h3>
                    <p className="text-base">{profileData.role}</p>
                  </div>

                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground mb-1">Territory</h3>
                    <p className="text-base">{profileData.territory}</p>
                  </div>

                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground mb-1">Status</h3>
                    <p className="text-base capitalize">{profileData.status}</p>
                  </div>

                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground mb-1">Join Date</h3>
                    <p className="text-base">{profileData.joinDate.toLocaleDateString()}</p>
                  </div>

                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground mb-1">Manager</h3>
                    <p className="text-base">{profileData.manager}</p>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-sm font-medium text-muted-foreground mb-1">Bio</h3>
              <p className="text-base">{profileData.bio || "No bio provided"}</p>
            </div>

            <div>
              <h3 className="text-lg font-medium mb-2">Address</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-1">Street Address</h4>
                  <p className="text-base">{profileData.address || "Not provided"}</p>
                </div>

                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-1">City</h4>
                  <p className="text-base">{profileData.city || "Not provided"}</p>
                </div>

                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-1">Region</h4>
                  <p className="text-base">{profileData.region || "Not provided"}</p>
                </div>

                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-1">Postal Code</h4>
                  <p className="text-base">{profileData.postalCode || "Not provided"}</p>
                </div>
              </div>
            </div>

            <div className="flex justify-end">
              <Button>Edit Profile</Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

