"use client"

import { useEffect, useState } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { collection, query, where, orderBy, limit, getDocs } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { useAuth } from "@/lib/auth-context"
import { formatCurrency } from "@/lib/currency-utils"

export function RecentSales() {
  const { user } = useAuth()
  const [recentSales, setRecentSales] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchRecentSales = async () => {
      if (!user) return

      try {
        setLoading(true)

        // Fetch recent orders
        const ordersQuery = query(
          collection(db, "orders"),
          where("agentId", "==", user.uid),
          orderBy("createdAt", "desc"),
          limit(5),
        )

        const ordersSnapshot = await getDocs(ordersQuery)
        const ordersData = []

        // Get customer details for each order
        for (const orderDoc of ordersSnapshot.docs) {
          const orderData = orderDoc.data()

          // Fetch customer data
          if (orderData.customerId) {
            const customerDoc = await getDocs(
              query(collection(db, "customers"), where("id", "==", orderData.customerId)),
            )

            if (!customerDoc.empty) {
              const customerData = customerDoc.docs[0].data()

              ordersData.push({
                id: orderDoc.id,
                customerName: customerData.name || "Unknown Customer",
                customerEmail: customerData.email || "",
                amount: orderData.totalAmount || 0,
                date: orderData.createdAt?.toDate() || new Date(),
                initials: getInitials(customerData.name || "Unknown Customer"),
              })
            } else {
              // Customer not found, use order data only
              ordersData.push({
                id: orderDoc.id,
                customerName: "Unknown Customer",
                customerEmail: "",
                amount: orderData.totalAmount || 0,
                date: orderData.createdAt?.toDate() || new Date(),
                initials: "UC",
              })
            }
          }
        }

        setRecentSales(ordersData)
      } catch (error) {
        console.error("Error fetching recent sales:", error)
        setRecentSales([])
      } finally {
        setLoading(false)
      }
    }

    fetchRecentSales()
  }, [user])

  // Helper function to get initials from name
  const getInitials = (name) => {
    return name
      .split(" ")
      .map((part) => part[0])
      .join("")
      .toUpperCase()
      .substring(0, 2)
  }

  if (loading) {
    return (
      <div className="space-y-8">
        <p className="text-sm text-muted-foreground">Loading recent sales...</p>
      </div>
    )
  }

  if (recentSales.length === 0) {
    return (
      <div className="space-y-8">
        <p className="text-sm text-muted-foreground">No recent sales found</p>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      {recentSales.map((sale) => (
        <div key={sale.id} className="flex items-center">
          <Avatar className="h-9 w-9">
            <AvatarImage src={`/placeholder.svg?height=36&width=36`} alt={sale.customerName} />
            <AvatarFallback>{sale.initials}</AvatarFallback>
          </Avatar>
          <div className="ml-4 space-y-1">
            <p className="text-sm font-medium leading-none">{sale.customerName}</p>
            <p className="text-sm text-muted-foreground">{sale.customerEmail}</p>
          </div>
          <div className="ml-auto font-medium">{formatCurrency(sale.amount)}</div>
        </div>
      ))}
    </div>
  )
}

