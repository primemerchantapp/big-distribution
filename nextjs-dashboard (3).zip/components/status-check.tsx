"use client"

import { useEffect, useState } from "react"
import { CheckCircle2, AlertCircle } from "lucide-react"

export function StatusCheck() {
  const [statuses, setStatuses] = useState({
    database: { status: "checking", message: "Checking connection..." },
    api: { status: "checking", message: "Checking API status..." },
    storage: { status: "checking", message: "Checking storage access..." },
  })

  useEffect(() => {
    const checkStatuses = async () => {
      // Check database connection
      try {
        const dbResponse = await fetch("/api/health?service=database", {
          method: "GET",
          cache: "no-store",
        })

        if (dbResponse.ok) {
          setStatuses((prev) => ({
            ...prev,
            database: { status: "online", message: "Database connection is active" },
          }))
        } else {
          setStatuses((prev) => ({
            ...prev,
            database: { status: "issue", message: "Database connection issue detected" },
          }))
        }
      } catch (error) {
        setStatuses((prev) => ({
          ...prev,
          database: { status: "issue", message: "Failed to check database status" },
        }))
      }

      // Check API status
      try {
        const apiResponse = await fetch("/api/health?service=api", {
          method: "GET",
          cache: "no-store",
        })

        if (apiResponse.ok) {
          setStatuses((prev) => ({
            ...prev,
            api: { status: "online", message: "API services are operational" },
          }))
        } else {
          setStatuses((prev) => ({
            ...prev,
            api: { status: "issue", message: "API service issue detected" },
          }))
        }
      } catch (error) {
        setStatuses((prev) => ({
          ...prev,
          api: { status: "issue", message: "Failed to check API status" },
        }))
      }

      // Check storage access
      try {
        const storageResponse = await fetch("/api/health?service=storage", {
          method: "GET",
          cache: "no-store",
        })

        if (storageResponse.ok) {
          setStatuses((prev) => ({
            ...prev,
            storage: { status: "online", message: "Storage services are accessible" },
          }))
        } else {
          setStatuses((prev) => ({
            ...prev,
            storage: { status: "issue", message: "Storage access issue detected" },
          }))
        }
      } catch (error) {
        setStatuses((prev) => ({
          ...prev,
          storage: { status: "issue", message: "Failed to check storage status" },
        }))
      }
    }

    checkStatuses()

    // Set up interval to check status every 5 minutes
    const intervalId = setInterval(checkStatuses, 5 * 60 * 1000)

    return () => clearInterval(intervalId)
  }, [])

  return (
    <div className="space-y-4">
      {Object.entries(statuses).map(([key, { status, message }]) => (
        <div key={key} className="flex items-center justify-between p-2 border rounded">
          <div className="flex items-center gap-2">
            {status === "online" ? (
              <CheckCircle2 className="h-5 w-5 text-green-500" />
            ) : status === "issue" ? (
              <AlertCircle className="h-5 w-5 text-amber-500" />
            ) : (
              <div className="h-5 w-5 rounded-full bg-gray-300 animate-pulse" />
            )}
            <span className="font-medium capitalize">{key}</span>
          </div>
          <span className="text-sm text-muted-foreground">{message}</span>
        </div>
      ))}
    </div>
  )
}

