/**
 * Formats a number as currency
 * @param amount The amount to format
 * @returns Formatted currency string with Philippine Peso symbol
 */
export const formatCurrency = (amount: number | string | null | undefined): string => {
  if (amount === null || amount === undefined) return "₱0.00"

  try {
    const numAmount = typeof amount === "string" ? Number.parseFloat(amount) : amount

    if (isNaN(numAmount)) return "₱0.00"

    return `₱${numAmount.toLocaleString("en-PH", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    })}`
  } catch (error) {
    console.error("Error formatting currency:", error)
    return "₱0.00"
  }
}

/**
 * Calculates percentage
 * @param value The value
 * @param total The total
 * @returns Formatted percentage string
 */
export const calculatePercentage = (value: number, total: number): string => {
  if (!total) return "0%"

  const percentage = (value / total) * 100
  return `${Math.round(percentage)}%`
}

/**
 * Formats a number with commas
 * @param num The number to format
 * @returns Formatted number string
 */
export const formatNumber = (num: number | string | null | undefined): string => {
  if (num === null || num === undefined) return "0"

  try {
    const numValue = typeof num === "string" ? Number.parseFloat(num) : num

    if (isNaN(numValue)) return "0"

    return numValue.toLocaleString("en-PH")
  } catch (error) {
    console.error("Error formatting number:", error)
    return "0"
  }
}

