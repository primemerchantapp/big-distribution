/**
 * Formats a date to a readable string
 * @param date The date to format
 * @returns Formatted date string
 */
export const formatDate = (date: Date | string | number | null | undefined): string => {
  if (!date) return "N/A"

  try {
    const dateObj = new Date(date)
    if (isNaN(dateObj.getTime())) return "Invalid Date"

    return dateObj.toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    })
  } catch (error) {
    console.error("Error formatting date:", error)
    return "Error"
  }
}

/**
 * Gets time elapsed since a date
 * @param date The date to calculate from
 * @returns Human-readable time elapsed
 */
export const getTimeElapsed = (date: Date | string | number | null | undefined): string => {
  if (!date) return "Never"

  try {
    const dateObj = new Date(date)
    if (isNaN(dateObj.getTime())) return "Invalid Date"

    const now = new Date()
    const diffMs = now.getTime() - dateObj.getTime()

    // Convert to appropriate time unit
    const diffSec = Math.floor(diffMs / 1000)
    if (diffSec < 60) return `${diffSec} seconds ago`

    const diffMin = Math.floor(diffSec / 60)
    if (diffMin < 60) return `${diffMin} minutes ago`

    const diffHour = Math.floor(diffMin / 60)
    if (diffHour < 24) return `${diffHour} hours ago`

    const diffDay = Math.floor(diffHour / 24)
    if (diffDay < 30) return `${diffDay} days ago`

    const diffMonth = Math.floor(diffDay / 30)
    if (diffMonth < 12) return `${diffMonth} months ago`

    const diffYear = Math.floor(diffMonth / 12)
    return `${diffYear} years ago`
  } catch (error) {
    console.error("Error calculating time elapsed:", error)
    return "Error"
  }
}

/**
 * Formats a date for database storage
 * @param date The date to format
 * @returns ISO string date
 */
export const formatDateForStorage = (date: Date | string | number | null | undefined): string => {
  if (!date) return ""

  try {
    const dateObj = new Date(date)
    if (isNaN(dateObj.getTime())) return ""

    return dateObj.toISOString()
  } catch (error) {
    console.error("Error formatting date for storage:", error)
    return ""
  }
}

