import { ref, get, set, update, remove, query, orderByChild, equalTo } from "firebase/database"
import { db } from "@/lib/firebase"

// Add these utility functions at the top of the file to standardize error handling and responses

// Generic error handler for database operations
const handleDbError = (operation: string, error: any) => {
  console.error(`Error during ${operation}:`, error)
  throw new Error(`Failed to ${operation}: ${error.message || "Unknown error"}`)
}

// Generic fetch function with error handling
const fetchData = async (path: string, operation = "fetch data") => {
  try {
    const snapshot = await get(ref(db, path))
    return snapshot.exists() ? snapshot.val() : {}
  } catch (error) {
    return handleDbError(operation, error)
  }
}

// Now update the existing functions to use these utilities

// Agents
export const getAgents = async () => {
  return fetchData("agents", "fetch agents")
}

export const getAgentById = async (id: string) => {
  try {
    const snapshot = await get(ref(db, `agents/${id}`))
    return snapshot.exists() ? snapshot.val() : null
  } catch (error) {
    return handleDbError(`fetch agent ${id}`, error)
  }
}

// Add a function to get agents with their performance metrics
export const getAgentsWithMetrics = async () => {
  try {
    const agentsData = await getAgents()
    const ordersData = await getOrders()

    // Calculate metrics for each agent
    const agentsWithMetrics = Object.entries(agentsData).map(([id, agent]: [string, any]) => {
      const agentOrders = Object.values(ordersData).filter((order: any) => order.agent_id === id)
      const totalSales = agentOrders.reduce((sum: number, order: any) => sum + (order.total_amount || 0), 0)

      return {
        id,
        ...agent,
        total_sales: totalSales,
        orders_count: agentOrders.length,
      }
    })

    return agentsWithMetrics
  } catch (error) {
    return handleDbError("fetch agents with metrics", error)
  }
}

// Customers
export const getCustomers = async () => {
  const snapshot = await get(ref(db, "customers"))
  return snapshot.exists() ? snapshot.val() : {}
}

export const getCustomerById = async (id: string) => {
  const snapshot = await get(ref(db, `customers/${id}`))
  return snapshot.exists() ? snapshot.val() : null
}

export const getCustomersByAgentId = async (agentId: string) => {
  const customersRef = ref(db, "customers")
  const customersQuery = query(customersRef, orderByChild("agent_id"), equalTo(agentId))
  const snapshot = await get(customersQuery)
  return snapshot.exists() ? snapshot.val() : {}
}

export const createCustomer = async (customer: any) => {
  const newCustomerRef = ref(db, `customers/${customer.id}`)
  await set(newCustomerRef, customer)
  return customer
}

export const updateCustomer = async (id: string, data: any) => {
  const customerRef = ref(db, `customers/${id}`)
  await update(customerRef, data)
  return { id, ...data }
}

export const deleteCustomer = async (id: string) => {
  const customerRef = ref(db, `customers/${id}`)
  await remove(customerRef)
  return id
}

// Orders
export const getOrders = async () => {
  const snapshot = await get(ref(db, "orders"))
  return snapshot.exists() ? snapshot.val() : {}
}

export const getOrderById = async (id: string) => {
  const snapshot = await get(ref(db, `orders/${id}`))
  return snapshot.exists() ? snapshot.val() : null
}

export const getOrdersByAgentId = async (agentId: string) => {
  const ordersRef = ref(db, "orders")
  const ordersQuery = query(ordersRef, orderByChild("agent_id"), equalTo(agentId))
  const snapshot = await get(ordersQuery)
  return snapshot.exists() ? snapshot.val() : {}
}

export const createOrder = async (order: any) => {
  const newOrderRef = ref(db, `orders/${order.id}`)
  await set(newOrderRef, order)
  return order
}

export const updateOrder = async (id: string, data: any) => {
  const orderRef = ref(db, `orders/${id}`)
  await update(orderRef, data)
  return { id, ...data }
}

// Products
export const getProducts = async () => {
  const snapshot = await get(ref(db, "products"))
  return snapshot.exists() ? snapshot.val() : {}
}

export const getProductById = async (id: string) => {
  const snapshot = await get(ref(db, `products/${id}`))
  return snapshot.exists() ? snapshot.val() : null
}

// Users
export const getUserById = async (id: string) => {
  const snapshot = await get(ref(db, `users/${id}`))
  return snapshot.exists() ? snapshot.val() : null
}

export const updateUser = async (id: string, data: any) => {
  const userRef = ref(db, `users/${id}`)
  await update(userRef, data)
  return { id, ...data }
}

// Agents
export const updateAgent = async (id: string, data: any) => {
  const agentRef = ref(db, `agents/${id}`)
  await update(agentRef, data)
  return { id, ...data }
}

export const deleteAgent = async (id: string) => {
  const agentRef = ref(db, `agents/${id}`)
  await remove(agentRef)
  return id
}

export const createAgent = async (agent: any) => {
  const newAgentRef = ref(db, `agents/${agent.id}`)
  await set(newAgentRef, agent)
  return agent
}

// Products
export const updateProduct = async (id: string, data: any) => {
  const productRef = ref(db, `products/${id}`)
  await update(productRef, data)
  return { id, ...data }
}

export const deleteProduct = async (id: string) => {
  const productRef = ref(db, `products/${id}`)
  await remove(productRef)
  return id
}

export const createProduct = async (product: any) => {
  const newProductRef = ref(db, `products/${product.id}`)
  await set(newProductRef, product)
  return product
}

// Orders
export const deleteOrder = async (id: string) => {
  const orderRef = ref(db, `orders/${id}`)
  await remove(orderRef)
  return id
}

