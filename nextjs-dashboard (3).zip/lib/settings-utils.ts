import { ref, get, set, update } from "firebase/database"
import { db } from "@/lib/firebase"

// Types for settings
export interface UserSettings {
  darkMode: boolean
  language: string
  timeZone: string
  emailNotifications: boolean
  pushNotifications: boolean
  smsNotifications: boolean
  notificationFrequency: string
}

export interface AdminSettings {
  system: {
    companyName: string
    supportEmail: string
    contactPhone: string
    maxAgents: number
    maxCustomersPerAgent: number
    enableRegistration: boolean
    requireApproval: boolean
    enableLocationTracking: boolean
    mapApiKey: string
    defaultMapCenter: string
    defaultMapZoom: number
    mapType: string
  }
  notifications: {
    enableEmailNotifications: boolean
    enablePushNotifications: boolean
    enableSmsNotifications: boolean
    adminEmailRecipients: string
    dailyReportTime: string
    notifyOnNewCustomer: boolean
    notifyOnNewOrder: boolean
    notifyOnAgentRegistration: boolean
  }
  appearance: {
    logoUrl: string
    primaryColor: string
    companyTagline: string
    showWelcomeMessage: boolean
    welcomeMessage: string
  }
}

// Default settings
export const defaultUserSettings: UserSettings = {
  darkMode: false,
  language: "en",
  timeZone: "est",
  emailNotifications: true,
  pushNotifications: true,
  smsNotifications: false,
  notificationFrequency: "realtime",
}

export const defaultAdminSettings: AdminSettings = {
  system: {
    companyName: "Your Company",
    supportEmail: "support@example.com",
    contactPhone: "+63 (555) 123-4567",
    maxAgents: 50,
    maxCustomersPerAgent: 100,
    enableRegistration: true,
    requireApproval: true,
    enableLocationTracking: true,
    mapApiKey: "",
    defaultMapCenter: "12.8797, 121.774",
    defaultMapZoom: 6,
    mapType: "roadmap",
  },
  notifications: {
    enableEmailNotifications: true,
    enablePushNotifications: true,
    enableSmsNotifications: false,
    adminEmailRecipients: "admin@example.com",
    dailyReportTime: "06:00",
    notifyOnNewCustomer: true,
    notifyOnNewOrder: true,
    notifyOnAgentRegistration: true,
  },
  appearance: {
    logoUrl: "",
    primaryColor: "#4f46e5",
    companyTagline: "Your trusted business partner",
    showWelcomeMessage: true,
    welcomeMessage: "Welcome to our sales management system!",
  },
}

// User settings functions
export const getUserSettings = async (userId: string): Promise<UserSettings> => {
  try {
    const settingsRef = ref(db, `users/${userId}/settings`)
    const snapshot = await get(settingsRef)

    if (snapshot.exists()) {
      return snapshot.val()
    }

    // If no settings exist, create default settings
    await set(settingsRef, defaultUserSettings)
    return defaultUserSettings
  } catch (error) {
    console.error("Error fetching user settings:", error)
    return defaultUserSettings
  }
}

export const updateUserSettings = async (userId: string, settings: Partial<UserSettings>): Promise<void> => {
  try {
    const settingsRef = ref(db, `users/${userId}/settings`)
    await update(settingsRef, settings)
  } catch (error) {
    console.error("Error updating user settings:", error)
    throw new Error("Failed to update settings")
  }
}

// Admin settings functions
export const getAdminSettings = async (): Promise<AdminSettings> => {
  try {
    const settingsRef = ref(db, "admin_settings")
    const snapshot = await get(settingsRef)

    if (snapshot.exists()) {
      return snapshot.val()
    }

    // If no settings exist, create default settings
    await set(settingsRef, defaultAdminSettings)
    return defaultAdminSettings
  } catch (error) {
    console.error("Error fetching admin settings:", error)
    return defaultAdminSettings
  }
}

export const updateAdminSettings = async (
  category: "system" | "notifications" | "appearance",
  settings: Partial<AdminSettings[typeof category]>,
): Promise<void> => {
  try {
    const settingsRef = ref(db, `admin_settings/${category}`)
    await update(settingsRef, settings)
  } catch (error) {
    console.error(`Error updating admin ${category} settings:`, error)
    throw new Error("Failed to update settings")
  }
}

