// Validation utilities for data integrity

/**
 * Validates a date string
 * @param dateString The date string to validate
 * @returns True if the date is valid, false otherwise
 */
export const isValidDate = (dateString: string): boolean => {
  if (!dateString) return false

  const date = new Date(dateString)
  return !isNaN(date.getTime())
}

/**
 * Validates a numeric value
 * @param value The value to validate
 * @returns The numeric value or 0 if invalid
 */
export const validateNumber = (value: any): number => {
  if (value === null || value === undefined) return 0

  const num = Number(value)
  return isNaN(num) ? 0 : num
}

/**
 * Validates an email address
 * @param email The email to validate
 * @returns True if the email is valid, false otherwise
 */
export const isValidEmail = (email: string): boolean => {
  if (!email) return false

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  return emailRegex.test(email)
}

/**
 * Validates a phone number
 * @param phone The phone number to validate
 * @returns True if the phone number is valid, false otherwise
 */
export const isValidPhone = (phone: string): boolean => {
  if (!phone) return false

  // Simple validation - can be enhanced for specific formats
  const phoneRegex = /^[+]?[(]?[0-9]{3}[)]?[-\s.]?[0-9]{3}[-\s.]?[0-9]{4,6}$/
  return phoneRegex.test(phone)
}

/**
 * Ensures a string has a value
 * @param value The string to validate
 * @param defaultValue The default value if invalid
 * @returns The validated string or default value
 */
export const validateString = (value: any, defaultValue = ""): string => {
  if (value === null || value === undefined) return defaultValue
  return String(value)
}

/**
 * Validates an object ID
 * @param id The ID to validate
 * @returns True if the ID is valid, false otherwise
 */
export const isValidId = (id: string): boolean => {
  return !!id && typeof id === "string" && id.length > 0
}

